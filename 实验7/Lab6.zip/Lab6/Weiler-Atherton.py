import wx
import time

class Weiler(wx.Frame):
    def __init__(self):
        super().__init__(None,title='多边形裁剪算法',size=(800,800)) # 设置标题和窗口大小
        self.Center() # 居中显示

        # 绑定用户交互的函数
        self.Bind(wx.EVT_LEFT_DOWN, self.left_down)
        self.Bind(wx.EVT_RIGHT_DOWN,self.right_down)

        self.Flag = True # 判断绘制裁剪图形还是裁剪窗口
        self.target = [] # 存储裁剪图形的顶点坐标
        self.window = [] # 存储裁剪窗口的顶点坐标

        self.dc = wx.ClientDC(self) # 绘制设备上下文
        self.dc.SetBackground(wx.Brush(self.GetBackgroundColour()))
        # 设置画笔颜色做出区分
        pen_color1 = '#cc66ff'
        self.pen1 = wx.Pen(pen_color1, width=1)
        pen_color2 = '#00aaff'
        self.pen2 = wx.Pen(pen_color2, width=1)
        self.dc.SetPen(self.pen1)

    # 响应鼠标左键按下的事件
    def left_down(self,event):
        pos = event.GetPosition() # 获取鼠标位置
        if self.Flag: # 绘制裁剪图形
            if self.target != []:
                self.dc.DrawLine(self.target[-1],pos)
            self.target.append(pos)
        else: # 绘制裁剪窗口
            if self.window != []:
                self.dc.DrawLine(self.window[-1], pos)
            self.window.append(pos)

    # 响应鼠标右键按下的事件
    def right_down(self,event):
        pos = event.GetPosition()
        if self.Flag: # 封闭裁剪图形
            self.dc.DrawLine(pos,self.target[0])
            self.dc.SetPen(self.pen2)
        else: # 封闭裁剪窗口
            self.dc.DrawLine(pos,self.window[0])
            crop_seq = self.crop(self.target,self.window)
            # self.target = []
            self.dc.Clear()
            self.dc.DrawPolygon(self.window)
            self.dc.SetPen(self.pen1)
            for line in crop_seq:
                for i in range(len(line)-1):
                    self.dc.DrawLine(line[i],line[i+1])
            # self.window = []
        self.Flag = not self.Flag

    # 排序时使用的函数
    def cmp(self,x,y):
        return (x[0]-y[0])**2+(x[1]-y[1])**2


    # 计算两条直线交点坐标的函数
    def calcu(self,point0, point1, point2, point3):
        """
            point0: l1起点坐标
            point1: l1终点坐标
            point2: l2起点坐标
            point3: l2终点坐标
            若存在交点返回交点坐标
            若不存在交点return False
        """
        x0, y0 = point0
        x1, y1 = point1
        x2, y2 = point2
        x3, y3 = point3
        a1 = y1 - y0
        b1 = x1 - x0
        c1 = b1 * y0 - a1 * x0
        a2 = y3 - y2
        b2 = x3 - x2
        c2 = b2 * y2 - a2 * x2
        d = a1 * b2 - a2 * b1
        if d == 0:
            return False
        else:
            x = (b1 * c2 - b2 * c1) / d
            y = (a1 * c2 - a2 * c1) / d
            if (x-x0)*(x-x1)<0 and (x-x2)*(x-x3)<0:
                return (int(x),int(y))
            else:
                return False

    # 对图形进行裁剪并绘制
    def crop(self,target,window):
        """
        target: 裁剪图形的顶点坐标列表
        window: 裁剪窗口的顶点坐标列表
        """
        seq = self.makeseq(self.target,self.window)
        
        crop_seq = []
        line = []
        start = True
        # 寻找入点和出点
        # 并按照入点到出点的顺序进行截取
        for point in seq:
            if type(point) == type((1,1)):
                line.append(point)
                start = not start
                if start:
                    crop_seq.append(line)
                    line = []
            elif not start:
                line.append(point)
        return crop_seq


    # 生成裁剪图形的顶点序列
    def makeseq(self,target,window):
        # 对于每一条边，将其与裁剪窗口的每一条边进行求交
        # 对于交点按照与顶点的距离进行排序
        seq = []
        for i in range(len(target)):
            seq.append(target[i])
            linepoints = []
            point0 = target[i]
            point1 = target[(i + 1) % len(target)]
            for j in range(len(window)):
                point2 = window[j]
                point3 = window[(j + 1) % len(window)]
                # 求交点
                intersect = self.calcu(point0, point1, point2, point3)
                if intersect:
                    linepoints.append(intersect)
                # 将交点按照与顶点的距离进行排序
                linepoints = sorted(linepoints,key = lambda x:self.cmp(x,point0))
            seq += linepoints
        return seq


if __name__ == '__main__':
    app = wx.App() # 实例化wx对象
    weiler = Weiler() # 实例化Weiler类
    weiler.Show() # 生成界面
    app.MainLoop() # wx主循环