## 实验步骤

### 实现 数值微分法(DDA) 直线算法

### 实现 `Bresenham` 直线算法

### 实现窗体直线绘制功能

### 结果展示
![result](figure/result.png)