#pragma once

#ifndef __DRAW_LINE_GLOBLE_H__
#define __DRAW_LINE_GLOBLE_H__


struct Point {
    int x,y;
};

struct Color {
    int r,g,b;
};

#endif